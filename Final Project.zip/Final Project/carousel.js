var my_pics;

jsLib.event.add(window, "load", function () {
    var options = {
        height: 550,
        maxAspect: 0.3,
        minSize: 0.4,
        maxSpeed: 4
    }
    //var options = {
    //  height: 500,
    //maxSpeed: 5
    //}
    my_pics = new Carousel("my_pics", options); // options paramter removed
});
