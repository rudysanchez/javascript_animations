// Detect required jsLib objects
if (!jsLib) {
    throw new Error("Carousel: Requires jsLib_css, jsLib_event, " +
        "jsLib_event_mouse, and jsLib_event_keyboard");
}
else if (!jsLib.css) {
    throw new Error("Carousel: Requires jsLib_css");
}
else if (!jsLib.event) {
    throw new Error("Carousel: Requires jsLib_event, " +
        "jsLib_event_mouse, and jsLib_event_keyboard");
}
else if (!jsLib.event.mouse) {
    throw new Error("Carousel: Requires jsLib_event_mouse");
}
else if (!jsLib.event.keyboard) {
    throw new Error("Carousel: Requires jsLib_event_keyboard");
}

// Sign method used by the updateImage method
Math.sign = function (value) {
    if (value > 0) return 1; // return 1 if value is +
    if (value < 0) return -1; // return -1 is value -
    return 0; // return 0 if value is 0
}

/******************************************************************************
* Define the ImageElement object.
* This object controls the images in the carousel.
******************************************************************************/
var ImageElement = function (divNode, imageNode) { // carousel element and image element
    this.div = divNode; // Store ref. to elements in object's properties
    this.image = imageNode; // Store ref. to elements in object's properties
    this.originalWidth = this.image.width; // Store original width of image in object property
    this.originalHeight = this.image.height; // Store original height of image in object property
    this.image.style.position = "absolute"; // Set position of image to absolute
}

// Return object with width/height properties set to original width/height of image.
ImageElement.prototype.getOriginalSize = function () {
    return { width: this.originalWidth, height: this.originalHeight };
}

// This method takes 4 parameters and updates the image position based on these values.
ImageElement.prototype.updateImage = function (maxSize, angle, aspect, minSize) {
    // 1. Calculate the bounds for the images
    var maxWidth = this.div.clientWidth / 2; // Store the max width of the image
    var maxHeight = this.div.clientHeight * (1 - Math.abs(aspect)); // Store max height
    // Store the coordinates for the center of the carousel
    var centerX = jsLib.css.getOffsetLeft(this.div) + this.div.clientWidth / 2;
    var centerY = jsLib.css.getOffsetTop(this.div) + this.div.clientHeight / 2;
    // Store the largest distances that the images are allowed ot move from center of carousel
    var maxX = this.div.clientWidth / 2 - maxWidth / 2;
    var maxY = this.div.clientHeight / 2 - maxHeight / 2;
    var maxZ = 100; // max depth of image

    // 2. Calculate 3D position
    var angleRadians = angle * Math.PI / 180; // Angle of image after conversion degrees to radians
    var deltaX = Math.cos(angleRadians) * maxX; // Change in hor. distance from center of carousel to cent. img
    // Change in vertical distance from carousel center to img center
    var deltaY = Math.sin(angleRadians) * maxY * Math.sin(aspect) * -1;
    var deltaZ = Math.sin(angleRadians) * maxZ * -1 + maxZ; // Change in depth

    // 3. Calculate image size based on depth
    // Calc. scale var. based on deltaZ and ensure it's between minSize and 1
    var scale = (deltaZ / (maxZ * 2)) * (1 - minSize) + minSize;
    // Multiply max width and max height by scale variable to calc. width/height of img
    var imageWidth = maxSize.width * scale;
    var imageHeigth = maxSize.height * scale;

    // 4. Calculate x and y coordinates for image's position on screen
    var x = centerX + deltaX - this.image.width / 2;
    var y = centerY + deltaY - this.image.height / 2;

    // 5. Set the position, zIndex, and size of image to the values calculated in this method
    this.image.style.left = Math.round(x) + "px"; // px position from left
    this.image.style.top = Math.round(y) + "px"; // px from top
    this.image.style.zIndex = Math.round(deltaZ); // depth is zIndex
    this.image.width = Math.round(imageWidth); // width of image
    this.image.height = Math.round(imageHeigth); // height of image
}

/******************************************************************************
* Define the Carousel object which controls the carousel.
******************************************************************************/
var Carousel = function (id, options) { // id attr for div element, options is optional parameters
    // 1. Create an options object if necessary. Prevents uneccessary errors.
    if (!options) options = {}; // options object if necessary

    // 2. Set the default height property for the carousel.
    if (isNaN(options.height)) { // if options parameter has an invalid height property
        this.height = 400; // set ht to 400
    }
    else { // if options parameter has valid height
        this.height = parseInt(options.height); // convert options parameter height to int
        this.height = Math.max(this.height, 50);
    }

    // 3. Set default for maxAspect or get from options param
    if (isNaN(options.maxAspect)) {
        this.maxAspect = 0.5;
    } else {
        this.maxAspect = parseFloat(options.maxAspect);
        this.maxAspect = Math.max(this.maxAspect, 0);
        this.maxAspect = Math.min(this.maxAspect, .75);
    }

    // 4. Set default for minSize or get from options param
    if (isNaN(options.minSize)) {
        this.minSize = 0.15;
    } else {
        this.minSize = parseFloat(options.minSize);
        this.minSize = Math.max(this.minSize, 0.05);
        this.minSize = Math.min(this.minSize, 0.95);
    }

    // 5. Set default for maxSpeed or get from options param
    if (isNaN(options.maxSpeed)) {
        this.maxSpeed = 10;
    } else {
        this.maxSpeed = parseFloat(options.maxSpeed);
        this.maxSpeed = Math.max(this.maxSpeed, 1);
        this.maxSpeed = Math.min(this.maxSpeed, 45);
    }

    // 6. Set internal properties and variables
    this.aspect = Math.min( this.maxAspect, 0.40 );
    this.speed = this.maxSpeed;
    this.paused = false;
    this.angle = 0;
    var that = this;

    // 7. Get div element from id param
    this.div = document.getElementById(id);

    // Validate div element
    if ( !this.div ) {
        throw new Error("Carousel: ID is not an element.");
    }
    if ( this.div.nodeType !== 1 || this.div.nodeName !== "DIV" ) {
        throw new Error("Carousel: ID is not a DIV tag.");
    }

    // 8. Get image nodes
    var imgNodes = this.div.getElementsByTagName("img");
    
    // Validate image nodes
    if ( imgNodes.length == 0 ) {
        throw new Error("Carousel: DIV tag needs at least one image.");
    }

    // 9. Store image nodes in images property
    this.images = [];
    var imageNode, imageElement;
    for ( var i = 0; i < imgNodes.length; i++ ) {
        imageNode = imgNodes[i];
        imageElement = new ImageElement(this.div, imgNodes[i]);
        this.images.push( imageElement );
    }

    // 10. Set height of div element
    this.div.style.height = this.height + "px";

    // 11. Attach event handlers
    jsLib.event.add(this.div, "mousemove", function(evt) {
        that.mousemoveHandler(evt);
    });
    var htmlElement = document.getElementsByTagName("html")[0];
    jsLib.event.add(htmlElement, "keydown", function(evt) {
        that.keydownHandler(evt);
    });

    // 12. Start animation
    this.onTimer();
    setInterval( function() { that.onTimer(); }, 50 );
}

Carousel.prototype.mousemoveHandler = function (evt) {
    // 1. Set null zone width to stop carousel
    var nullWidth = 1 / (this.maxSpeed * 2 + 1);
    var nullMin = 0.5 - ( nullWidth / 2 );
    var nullMax = 0.5 + ( nullWidth / 2 );

    // 2. Determine mouse position in percent
    var baseX = jsLib.css.getOffsetLeft(this.div);
    var mousePct = (evt.clientX - baseX) / 
        this.div.clientWidth;

    // 3. Set speed based on mouse position
    if ( mousePct > nullMin && mousePct < nullMax ) {
        this.speed = 0;
    } else if ( mousePct <= nullMin ) {
        this.speed = Math.floor(
            -this.maxSpeed * ((nullMin - mousePct) / nullMin)
        );
    } else {
        this.speed = Math.ceil(
            this.maxSpeed * ((mousePct - nullMax) / nullMin)
        );
    }
}

Carousel.prototype.keydownHandler = function (evt) {

    /*****
    * Make sure CTRL and a direction works on all browsers
    *****/
    var ctrlIsDown; // Create a local variable
    if ("getModifierState" in evt) {
        if (evt.getModifierState("Ctrl")) { // If CTRL modifier is active (pressed)
            ctrlIsDown = true; // Boolean returns true
        }
    }
    else { // If CTRL modifier is inactive (not pressed)
        ctrlIsDown = evt.ctrlKey;
    }
    if (ctrlIsDown) { // If true
        switch (evt.keyIdentifier) {
            case "Up":      // CTRL-Up        
                this.aspect += 0.05;
                this.aspect = Math.min(this.aspect, this.maxAspect);
                break;
            case "Down":    // CTRL-Down
                this.aspect -= 0.05;
                this.aspect = Math.max(this.aspect, -this.maxAspect);
                break;
            case "Right":   // CTRL-Right        
                this.speed = this.maxSpeed * 0.7;
                this.paused = false;
                break;
            case "Left":    // CTRL-Left
                this.speed = -this.maxSpeed * 0.7;
                this.paused = false;
                break;
            case "U+001B":  // Escape key
                this.paused = !this.paused;
                break;
        }
    }
}

Carousel.prototype.onTimer = function () {
    // 1. Update angle if not paused
    if (!this.paused) {
        this.angle = (this.angle + this.speed) % 360;
        this.angle = (this.angle < 0) ? this.angle + 360 : this.angle;
    }

    // 2. Find tallest and widest image 
    var largestWidth = -Infinity;
    var largestHeight = -Infinity;
    var i, imageSize;
    for (i in this.images) {
        imageSize = this.images[i].getOriginalSize();
        largestWidth = Math.max(largestWidth, imageSize.width);
        largestHeight = Math.max(largestHeight, imageSize.height);
    }

    // 3. Calculate scale for images to fit in largest size
    var maxWidth = this.div.clientWidth / 2;
    var maxHeight = this.div.clientHeight * (1 - Math.abs(this.aspect));
    var scaleX = maxWidth / largestWidth;
    var scaleY = maxHeight / largestHeight;
    var scale = Math.min(scaleX, scaleY);

    // 4. Position and size images
    var angle, angleOffset;
    for (i in this.images) {
        // Calculate image size
        imageSize = this.images[i].getOriginalSize();
        imageSize.width *= scale;
        imageSize.height *= scale;

        // Calculate image angle
        angleOffset = 360 * (i / this.images.length);
        angle = (this.angle + angleOffset) % 360;

        // Call updateImage method
        this.images[i].updateImage(imageSize, angle,
                                    this.aspect, this.minSize);
    }
}