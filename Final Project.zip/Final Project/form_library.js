var $ = function (id) { return document.getElementById(id) }

var RegisterForm = function () {
    this.fields = [];
    this.fields["first_name"] = {};
    this.fields["last_name"] = {};
    this.fields["email"] = {};
    this.fields["zip"] = {};
    this.fields["birthday"] = {};
    this.fields["phone"] = {};

    // Default field messages
    this.fields["email"].message = "Must be a valid email address.";
    this.fields["zip"].message = "Use 5 digit ZIP code.";
    this.fields["birthday"].message = "Use mm/dd/yyyy format.";
    this.fields["phone"].message = "Use 999-999-9999 format.";

    // Field error messages
    this.fields["email"].required = "Email is required.";
    this.fields["email"].isEmail = "Email is not valid.";
    this.fields["zip"].required = "ZIP Code is required.";
    this.fields["zip"].isZip = "ZIP Code is not valid.";
    this.fields["birthday"].required = "Birthday is required.";
    this.fields["birthday"].isBirthday = "Birthday is not valid.";
    this.fields["phone"].required = "Phone number is required.";
    this.fields["phone"].isPhone = "Phone number is not valid.";
}

// Validation methods
RegisterForm.prototype.tooShort = function (text, length) {
    return (text.length < length);
}

RegisterForm.prototype.matches = function (text1, text2) {
    return (text1 == text2);
}

RegisterForm.prototype.isEmail = function (text) {
    if (text.length == 0) return false; // If empty return false
    var parts = text.split("@"); // Split email in 2 at @
    if (parts.length != 2) return false; // If @ at front or end
    if (parts[0].length > 64) return false; // If part1 has more than 64 characters
    if (parts[1].length > 255) return false; // If part 2 has more than 255 characters
    var address =
        "(^[\\w!#$%&'*+/=?^`{|}~-]+(\\.[\\w!#$%&'*+/=?^`{|}~-]+)*$)";
    var quotedText = "(^\"(([^\\\\\"])|(\\\\[\\\\\"]))+\"$)";
    var localPart = new RegExp(address + "|" + quotedText);
    if (!parts[0].match(localPart)) return false;
    var hostnames =
        "(([a-zA-Z0-9]\\.)|([a-zA-Z0-9][-a-zA-Z0-9]{0,62}[a-zA-Z0-9]\\.))+";
    var tld = "[a-zA-Z0-9]{2,6}";
    var domainPart = new RegExp("^" + hostnames + tld + "$");
    if (!parts[1].match(domainPart)) return false;
    return true;
}

RegisterForm.prototype.isZip = function (text) {
    return /^\d{5}(-\d{4})?$/.test(text);
}

RegisterForm.prototype.isPhone = function (text) {
    return /^\d{3}-\d{3}-\d{4}$/.test(text);
}

RegisterForm.prototype.isBirthday = function (text) {
    return /^[01]?\d\/[0-3]\d\/\d{4}$/.test(text);
}

RegisterForm.prototype.validateField = function (fieldName, text) {
    var field = this.fields[fieldName];
    if (field.required) {
        if (this.tooShort(text, 1)) {
            throw new Error(field.required);
        }
    }
    if (field.tooShort) {
        if (this.tooShort(text, field.tooShort[1])) {
            throw new Error(field.tooShort[0]);
        }
    }
    if (field.noMatch) {
        if (!this.matches(text, $(field.noMatch[1]).value)) {
            throw new Error(field.noMatch[0]);
        }
    }
    if (field.isEmail) {
        if (!this.isEmail(text)) {
            throw new Error(field.isEmail);
        }
    }
    if (field.isZip) {
        if (!this.isZip(text)) {
            throw new Error(field.isZip);
        }
    }
    if (field.isPhone) {
        if (!this.isPhone(text)) {
            throw new Error(field.isPhone);
        }
    }
    if (field.isBirthday) {
        if (!this.isBirthday(text)) {
            throw new Error(field.isBirthday);
        }
    }
}

// Error message methods
RegisterForm.prototype.resetErrors = function () {
    var message;
    for (var fieldName in this.fields) {
        $(fieldName + "_error").className = "";
        message = this.fields[fieldName].message;
        $(fieldName + "_error").firstChild.nodeValue =
            (message) ? message : "";
    }
}

RegisterForm.prototype.clearError = function (fieldName) {
    $(fieldName + "_error").className = "";
    $(fieldName + "_error").firstChild.nodeValue = "";
}

// Method to validate form
RegisterForm.prototype.validateForm = function () {
    var hasErrors = false;
    for (var fieldName in this.fields) {
        this.clearError(fieldName);
        try {
            this.validateField(fieldName, $(fieldName).value);
        } catch (error) {
            hasErrors = true;
            $(fieldName + "_error").className = "error";
            $(fieldName + "_error").firstChild.nodeValue = error.message;

        }
    }
    return hasErrors;
}
